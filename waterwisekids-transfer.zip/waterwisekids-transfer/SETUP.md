# WaterWiseKids Mac Mini Setup

## 1. Copy memory files
Copy the `.auto-memory/` folder into your Cowork project's `.auto-memory/` directory.
If one already exists, merge these files in and append the MEMORY.md entries.

## 2. Point Cowork at the waterwisekids.com repo folder
Clone if needed:
```
git clone https://github.com/mlopatnikov-bss/waterwisekids.git waterwisekids.com
cd waterwisekids.com && git checkout live
```

## 3. Verify
Ask Claude: "What do you know about the waterwisekids.com project?"
It should know the repo, deploy method, brand voice, and content strategy from memory.
