---
name: Michael - British Swim School operations
description: Michael runs customer service and operations for British Swim School franchises, manages waterwisekids.com
type: user
---

Michael (Mike) operates customer service and operations for British Swim School. He manages the WaterWiseKids.com website, which serves as a national water safety education platform. He uses GitHub Desktop on Mac for git operations and prefers direct action over lengthy explanations.
