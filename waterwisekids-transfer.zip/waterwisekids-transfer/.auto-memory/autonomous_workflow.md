---
name: WaterWiseKids autonomous publishing workflow
description: Step-by-step playbook for daily autonomous content creation, publishing, auditing, and site maintenance — follow this for all scheduled tasks
type: reference
---

## Daily Autonomous Workflow

### Step 1: Decide What to Publish Today
1. Read `content_strategy.md` for the topic pipeline and content types
2. Check what was recently published (read the git log on the live branch via Chrome on github.com)
3. Consider seasonality — prioritize timely topics (e.g., summer safety in May, holiday travel in November)
4. Rotate content types: education articles, location pages, seasonal content, parent resources

### Step 2: Create the Content
1. Read `brand_guidelines.md` before writing
2. Read an existing article (e.g., `/education/drowning-prevention-guide.html`) as an HTML template
3. Write the new page in the sandbox matching the exact same HTML structure, CSS, nav, footer
4. Follow all SEO rules from `seo_strategy.md` — title, meta, canonical, OG, schema, internal links
5. Ensure content is 1,500+ words, factually accurate, properly cited

### Step 3: Publish via Chrome on GitHub
**ALL GitHub operations go through Chrome browser (Claude in Chrome MCP). Never use sandbox git.**
1. Navigate to `https://github.com/mlopatnikov-bss/waterwisekids/tree/live`
2. Use "Add file" > "Create new file" to create the new HTML page
3. Paste the content, set the file path (e.g., `education/new-article.html`)
4. Commit directly to the `live` branch with a descriptive commit message
5. GitHub Pages auto-deploys from `live` branch

### Step 4: Update Supporting Files
1. Edit `sitemap.xml` on GitHub to add the new URL
2. Edit hub pages (e.g., `education/index.html`) to link to the new article
3. Edit `index.html` if the new content should be featured on the homepage
4. Each edit is a separate commit on the `live` branch via Chrome

### Step 5: Daily Site Audit
1. Visit `www.waterwisekids.com` via Chrome and verify the new page loads correctly
2. Check for broken links on the new page
3. Verify the page title, meta description, and schema render properly
4. Spot-check 2-3 existing pages for issues

### Step 6: Weekly/Monthly Tasks
- **Weekly:** Check Google Search Console (via Chrome), note any indexing issues
- **Weekly:** Review analytics for top/underperforming content
- **Monthly:** Update internal links, refresh hub pages, expand top articles
- **Monthly:** Competitor scan — search key terms, note what competitors rank for
- **Monthly:** Create social media draft posts for recent content

## Technical Details
- **GitHub repo:** mlopatnikov-bss/waterwisekids
- **Branch:** `live` (all publishing happens here)
- **Deployment:** GitHub Pages, auto-deploys on commit
- **Custom domain:** www.waterwisekids.com
- **DNS:** Cloudflare (account: Mlopatnikov@gmail.com), CNAME → mlopatnikov-bss.github.io
- **GTM:** GTM-5DN8B3QT (all pages)
- **Cache:** If content doesn't appear after deploy, purge Cloudflare cache

## Troubleshooting
- **Site shows old content:** Check Cloudflare DNS records and purge cache
- **GitHub Pages not deploying:** Check Actions tab on GitHub for failed workflows
- **Can't access GitHub from sandbox:** USE CHROME BROWSER, never sandbox git
