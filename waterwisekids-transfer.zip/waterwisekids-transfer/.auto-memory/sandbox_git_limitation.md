---
name: Sandbox cannot reach GitHub — use Chrome for all GitHub work
description: Sandbox proxy blocks github.com — ALL GitHub operations (edits, commits, branches, scheduled tasks) must go through Chrome browser on github.com
type: feedback
---

The sandbox routes all outbound traffic through a local proxy (localhost:3128) that uses a domain allowlist. github.com is NOT on the allowlist, so any git operation (push, pull, fetch, ls-remote) fails with "Received HTTP code 403 from proxy after CONNECT".

**Why:** Platform-level security restriction on the Cowork sandbox. Cannot be fixed from our side.

**How to apply:** ALL GitHub work — including scheduled activities — must use Chrome browser (Claude in Chrome MCP) to interact with github.com directly. This includes:
- Editing files and creating commits
- Managing branches
- Reviewing deployments and Actions
- Any scheduled or automated tasks that touch the repo

Do NOT use: sandbox git commands, PAT token scripts, Terminal workarounds, or GitHub Desktop. Chrome browser is the standard approach for everything GitHub-related.
