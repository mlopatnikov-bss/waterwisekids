---
name: GA4 validation status
description: GA4/GTM event tracking validation results and Chrome MCP limitation for analytics verification
type: project
---

**GA4 validation pass completed (2026-04-05).**

GTM container GTM-5DN8B3QT (Version 3, published). GA4 property G-KP7R3NLS4F (p527970109).

**Events configured in GTM:**
- checklist_signup — fires on dataLayer push, sends to GA4
- contact_form_submit — fires on dataLayer push, sends to GA4
- checklist_print — fires on dataLayer push, sends to GA4
- cta_click — fires on gtm.click with CSS selector `[data-cta]`, sends data-cta value as parameter

**Verification result:** All GTM tag configurations verified correct. All triggers match. Site code has correct dataLayer.push() calls. GA4 standard events flow.

**Known limitation:** Chrome MCP extension blocks all analytics/tracking network requests from tabs it manages. This means Tag Assistant cannot complete end-to-end custom event verification through Chrome MCP. Manual verification steps were provided to Michael for testing in a regular browser tab.

**Why:** Needed to confirm the site was actually collecting the intended GA4 events before entering live measurement phase.
**How to apply:** For future GA4 debugging, use Tag Assistant in a regular Chrome tab (not Chrome MCP managed). The GTM preview/debug URL pattern is tagassistant.google.com with GTM-5DN8B3QT.
