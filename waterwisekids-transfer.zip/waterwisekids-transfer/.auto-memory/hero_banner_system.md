---
name: Hero/banner CSS system
description: Shared .page-hero class system in main.css replaces all per-page inline hero CSS; details on variants and affected pages
type: project
---

Unified all internal page hero/banner styling into a shared class system in `assets/css/main.css` (added ~90 lines after the breadcrumb section, around line 781).

**Classes created:**
- `.page-hero` — base hero: blue gradient, white text, centered, 3.5rem padding
- `.page-hero h1` — 2.5rem, 700 weight, -0.02em tracking
- `.page-hero .hero-sub` — subtitle, 1.1rem, rgba white 0.9
- `.page-hero--edu` — Education Hub variant with teal-accent 4-color gradient and ::after fade
- `.page-breadcrumb` — shared breadcrumb nav styling
- Responsive breakpoint at 768px

**Pages updated (8 files in commit `04ea2f1`):**
- about/index.html — removed 22-line inline hero CSS
- contact/index.html — same pattern
- swim-lessons/index.html — removed 30-line inline hero CSS
- for-swim-schools/index.html — removed 28-line inline hero CSS
- education/index.html — removed 19-line inline hero CSS, uses `page-hero--edu` variant
- british-swim-school/jersey-shore.html — removed 4-line minified inline CSS, 3-level breadcrumb
- british-swim-school/northwest-philadelphia.html — same as jersey-shore
- assets/css/main.css — added shared hero system

**NOT touched:** index.html (homepage) — still uses its own `.hero` class with unique 80px padding, font-weight 800, CTA buttons.

**Why:** BSS profile pages had low-contrast hero text; all internal pages had duplicated, inconsistent inline hero CSS.
**How to apply:** Any new internal page should use `<section class="page-hero">` with `<div class="hero-content">`, `<h1>`, and `<p class="hero-sub">`. No inline hero CSS needed.
