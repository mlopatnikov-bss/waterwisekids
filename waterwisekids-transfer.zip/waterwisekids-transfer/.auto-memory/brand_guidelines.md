---
name: WaterWiseKids brand and editorial guidelines
description: Voice, tone, style rules, and brand identity for all waterwisekids.com content — must be followed for every page created
type: feedback
---

## Brand Identity
- **Name:** WaterWiseKids (one word, camelCase in logo/branding)
- **Tagline:** "Because Water Safety Saves Lives"
- **Mission:** Expand water safety knowledge nationwide while helping families find trusted, quality swim instruction
- **Operated by:** Michael Lopatnikov, British Swim School operator (NW Philadelphia & Jersey Shore)

## Voice & Tone
- **Warm, expert, empowering** — like a trusted swim instructor talking to a parent
- Never condescending, never fear-mongering
- Use "you/your" to address parents directly
- Authoritative but approachable — cite real data but explain it simply
- Encouraging about swim lessons without being salesy

## Style Rules
- Write in American English
- Use active voice
- Short paragraphs (2-4 sentences max)
- Use subheadings (H2, H3) to break up long articles
- Include emoji sparingly in section headers only (🏊 📚 🛟 etc.) — matches existing site style
- Numbers: spell out one through nine, use digits for 10+
- Ages: always use digits ("ages 1-3", "children under 4")
- Statistics: always cite the source (e.g., "According to the CDC...")

## What NOT to write
- No medical advice beyond first aid basics — always say "consult your pediatrician"
- No specific claims about British Swim School superiority over competitors
- No graphic descriptions of drowning incidents
- No guarantees about safety outcomes
- No content about topics unrelated to water safety, swimming, or family aquatics

## Design/HTML Standards
- All pages use the same CSS custom properties (blue-800, blue-600, orange-500, etc.)
- All pages include GTM-5DN8B3QT in head and body
- All pages use Inter font from Google Fonts
- Navigation: Water Safety, Find Lessons, For Swim Schools, About, Contact
- Footer: same sitewide footer with links, email, copyright

**Why:** Consistent brand voice builds trust with parents and search engines. Every page should feel like it belongs on the same site.

**How to apply:** Read these guidelines before creating ANY new content. Every page must pass these checks before publishing.
