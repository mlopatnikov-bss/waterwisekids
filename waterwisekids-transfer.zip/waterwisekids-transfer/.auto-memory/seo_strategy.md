---
name: WaterWiseKids SEO strategy
description: On-page SEO standards, keyword targets, technical SEO checklist, and ongoing optimization rules for waterwisekids.com
type: project
---

## On-Page SEO Standards (every new page MUST have)
1. **Title tag:** Primary keyword + brand, under 60 chars. Format: "Topic Title | WaterWiseKids"
2. **Meta description:** Compelling, includes primary keyword, 150-160 chars
3. **Canonical URL:** `<link rel="canonical" href="https://www.waterwisekids.com/[path]" />`
4. **Open Graph tags:** og:title, og:description, og:url, og:type, og:image
5. **H1:** One per page, includes primary keyword, different from title tag
6. **Internal links:** Minimum 2 links to other site pages, plus links from existing pages back to new content
7. **JSON-LD schema:** Article schema for education pages, LocalBusiness for swim school pages
8. **Image alt text:** Descriptive, keyword-aware (when images are added)
9. **URL slug:** Short, hyphenated, keyword-rich (e.g., `/education/backyard-pool-safety.html`)

## Technical SEO Tasks (ongoing)
- **Sitemap:** Update `/sitemap.xml` every time a new page is added
- **Robots.txt:** Already configured, check periodically
- **Internal linking audit:** Monthly — ensure new pages get linked from hub pages (`/education/index.html`, homepage)
- **Broken link check:** Weekly scan for 404s
- **Page speed:** Keep pages lightweight — inline CSS (no frameworks), minimal JS
- **Mobile-friendly:** All templates are responsive already

## Keyword Strategy
**Primary keyword clusters to target:**
- water safety for kids / children
- drowning prevention
- swim lessons [city/state]
- when to start swim lessons
- pool safety rules / tips
- toddler water safety
- how to teach a child to swim
- british swim school [location]
- swim school near me [city]
- water safety education

**Long-tail expansion approach:** Each article targets one primary keyword and 3-5 related long-tail phrases. Use natural language, not keyword stuffing.

## Local SEO (for swim school pages)
- Each location page targets "[brand] [city/area]" and "swim lessons [city]"
- Include: address/area served, Google Maps embed placeholder, local landmarks
- Add LocalBusiness JSON-LD schema with geo coordinates

## Ongoing SEO Activities
- **Daily:** Publish new content with proper on-page SEO
- **Weekly:** Check Google Search Console for indexing issues, review top-performing pages
- **Monthly:** Update internal links on hub pages to include new content, refresh sitemap submission, review keyword rankings
- **Quarterly:** Content refresh — update dates, stats, and expand top-performing articles

## Google Search Console
- Property: www.waterwisekids.com (to be verified if not already)
- Submit sitemap after every batch of new content
- Monitor: indexing coverage, mobile usability, core web vitals
