---
name: WaterWiseKids repo and deployment setup
description: GitHub repo structure, branches, GitHub Pages config, Cloudflare DNS, and local repo path for waterwisekids.com
type: project
---

**Repo:** https://github.com/mlopatnikov-bss/waterwisekids.git
**Local path on Mike's Mac:** /Users/mike/Documents/Claude/Projects/waterwisekids.com

**Branches:**
- `live` — clean 27-file site with GTM-5DN8B3QT, deployed via GitHub Pages
- `main` — old version with 329 commits and junk directories (advertise, gear, jobs, teens, swim-schools, functions). Not currently deployed.

**GitHub Pages config (as of 2026-04-05):**
- Source: Deploy from branch `live` / (root)
- Custom domain: www.waterwisekids.com
- CNAME file in repo root

**DNS / Cloudflare (as of 2026-04-05):**
- Domain DNS managed in Cloudflare (account: Mlopatnikov@gmail.com)
- `waterwisekids.com` CNAME → `mlopatnikov-bss.github.io` (Proxied)
- `www` CNAME → `mlopatnikov-bss.github.io` (Proxied)
- Previously pointed to Cloudflare Pages project `waterwisekids-git.pages.dev` which served old content — fixed by updating both CNAME records to GitHub Pages

**Why:** Site was rebuilt as a clean water safety education platform for British Swim School. The old main branch had accumulated junk content. DNS was previously pointing to a Cloudflare Pages project with old content instead of GitHub Pages.

**How to apply:** Deploy changes by editing files in the sandbox, then using GitHub Desktop to commit/push to the `live` branch. GitHub Pages auto-deploys from `live`. If site shows old content, check Cloudflare DNS records and purge Cloudflare cache.
