---
name: WaterWiseKids content strategy
description: Content types, topics pipeline, publishing cadence, and content creation rules for daily autonomous publishing on waterwisekids.com
type: project
---

## Publishing Cadence
**Daily new content** — 1 new page per day, 365+ pages/year. Full autonomy to create and publish without Michael's review.

## Content Types (all four active)

### 1. Water Safety Education Articles (`/education/`)
Evergreen guides on drowning prevention, pool safety, open water, CPR, water survival skills. These are the SEO backbone.
- Target: 1,500–2,500 words per article
- Always include actionable tips, stats from CDC/WHO/Red Cross, age-specific advice
- URL format: `/education/[slug].html`

### 2. Local Swim School Pages (`/british-swim-school/` and future `/swim-schools/`)
Location-specific landing pages for British Swim School territories and future partner schools. Drive local SEO.
- Include: area name, neighborhoods served, pool locations, programs offered, local context
- URL format: `/british-swim-school/[location-slug].html` or `/swim-schools/[brand]/[location].html`
- Current locations: Northwest Philadelphia, Jersey Shore. Expand to all BSS territories.

### 3. Seasonal & Timely Content (`/education/` or `/guides/`)
Content tied to seasons, holidays, awareness months, news. Publish ahead of season (e.g., summer safety articles in April/May).
- Water Safety Month (May), summer pool season, back-to-school, holiday travel, spring break
- Timely stats, local drowning incident awareness (without being exploitative)

### 4. Parent Resources (`/education/` or `/resources/`)
Age-specific guides, printable checklists, "what to pack" lists, swim readiness assessments.
- Target parents of kids 0–12
- Practical, shareable, actionable

## Existing Content (as of 2026-04-05, 8 education articles)
1. Drowning prevention guide
2. When to start swim lessons (age guide)
3. Fear of water (overcoming)
4. Pool safety rules
5. Lake & ocean safety
6. Toddler water safety (ages 1-3)
7. CPR basics for parents
8. Swim milestones by age

## Topic Pipeline (next priorities)
- Backyard pool fence requirements by state
- Water safety for kids with special needs
- How to choose a swim school (what to look for)
- Swim lesson FAQ for nervous parents
- Bath time safety for infants
- Water safety at vacation rentals / hotels
- Boating safety with children
- What to do if you see someone drowning
- Teach your child to float (survival swimming basics)
- Water safety for teens (unsupervised swimming risks)
- British Swim School location pages for all active territories

## Content Rules
- Never publish thin content (<800 words for articles)
- Every page must have: unique title, meta description, canonical URL, OG tags, JSON-LD schema
- All content must be factually accurate — cite CDC, AAP, Red Cross, WHO when using stats
- No fear-mongering — empowering and educational tone
- Every article links internally to at least 2 other pages on the site
- Update sitemap.xml after every new page
